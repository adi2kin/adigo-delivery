from flask import Flask, request, jsonify
from dotenv import load_dotenv
import os
import requests

load_dotenv()
app = Flask(__name__)

# Load keys
OPENAI_KEY = os.getenv("OPENAI_API_KEY")
GEMINI_KEY = os.getenv("GEMINI_API_KEY")
CLAUDE_KEY = os.getenv("CLAUDE_API_KEY")
GROK_KEY = os.getenv("GROK_API_KEY")
DEEPSEEK_KEY = os.getenv("DEEPSEEK_API_KEY")

@app.route("/api/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "")

    # Simple strategy: first available AI
    ai_reply = None

    if OPENAI_KEY:
        ai_reply = ask_openai(user_message)
    elif GEMINI_KEY:
        ai_reply = ask_gemini(user_message)
    elif CLAUDE_KEY:
        ai_reply = ask_claude(user_message)
    elif GROK_KEY:
        ai_reply = ask_grok(user_message)
    elif DEEPSEEK_KEY:
        ai_reply = ask_deepseek(user_message)

    if not ai_reply:
        ai_reply = "No AI keys configured yet!"

    return jsonify({"reply": ai_reply})

# Example dummy functions (you'll replace with real API calls)
def ask_openai(msg):
    return f"[OpenAI]: {msg}"

def ask_gemini(msg):
    return f"[Gemini]: {msg}"

def ask_claude(msg):
    return f"[Claude]: {msg}"

def ask_grok(msg):
    return f"[Grok]: {msg}"

def ask_deepseek(msg):
    return f"[DeepSeek]: {msg}"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

