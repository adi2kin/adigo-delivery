from flask import Flask, request, jsonify
from dotenv import load_dotenv
import os
import requests

load_dotenv()
app = Flask(__name__)

# Load keys
OPENAI_KEY = os.getenv("OPENAI_API_KEY")
GEMINI_KEY = os.getenv("GEMINI_API_KEY")
CLAUDE_KEY = os.getenv("CLAUDE_API_KEY")
GROK_KEY = os.getenv("GROK_API_KEY")
DEEPSEEK_KEY = os.getenv("DEEPSEEK_API_KEY")

@app.route("/api/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "")

    # Decide which AI to use based on which keys are present
    if OPENAI_KEY:
        ai_reply = ask_openai(user_message)
    elif GEMINI_KEY:
        ai_reply = ask_gemini(user_message)
    elif CLAUDE_KEY:
        ai_reply = ask_claude(user_message)
    elif GROK_KEY:
        ai_reply = ask_grok(user_message)
    elif DEEPSEEK_KEY:
        ai_reply = ask_deepseek(user_message)
    else:
        ai_reply = "No AI keys configured yet!"

    return jsonify({"reply": ai_reply})

# --- REAL API CALLS ---
def ask_openai(message):
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {OPENAI_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "model": "gpt-4o",  # adjust to your plan
        "messages": [{"role": "user", "content": message}]
    }
    res = requests.post(url, headers=headers, json=data)
    reply = res.json()["choices"][0]["message"]["content"]
    return f"[OpenAI]: {reply}"

def ask_gemini(message):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={GEMINI_KEY}"
    data = {"contents":[{"parts":[{"text": message}]}]}
    res = requests.post(url, json=data)
    reply = res.json()["candidates"][0]["content"]["parts"][0]["text"]
    return f"[Gemini]: {reply}"

def ask_claude(message):
    url = "https://api.anthropic.com/v1/messages"
    headers = {
        "x-api-key": CLAUDE_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
    }
    data = {
        "model": "claude-3-opus-20240229",  # adjust to your plan
        "max_tokens": 1000,
        "messages": [{"role": "user", "content": message}]
    }
    res = requests.post(url, headers=headers, json=data)
    reply = res.json()["content"][0]["text"]
    return f"[Claude]: {reply}"

def ask_grok(message):
    # Replace with real Grok API call; placeholder:
    return f"[Grok]: {message}"

def ask_deepseek(message):
    # Replace with real DeepSeek API call; placeholder:
    return f"[DeepSeek]: {message}"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
